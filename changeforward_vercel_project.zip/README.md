# ChangeForward Landing Page (Vercel Ready)

## ✅ Setup
1. Rename `.env.local.example` to `.env.local`
2. Add your Mailchimp API key, list ID, and server prefix (e.g. `us17`)
3. Deploy to Vercel or run locally:

```bash
npm install
npm run dev
```

## 🌐 Features
- Multilingual support (EN/ES/FR)
- Mailchimp email signup integration
- Press kit download link
- Mobile-first design
