export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { email } = req.body;
  const data = {
    email_address: email,
    status: "subscribed"
  };

  const response = await fetch(`https://${process.env.MC_DC}.api.mailchimp.com/3.0/lists/${process.env.MC_LIST_ID}/members`, {
    method: "POST",
    headers: {
      Authorization: `apikey ${process.env.MC_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(data)
  });

  if (response.status >= 400) {
    return res.status(400).json({ error: "Subscription failed" });
  }

  return res.status(201).json({ success: true });
}
